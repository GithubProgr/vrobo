package com.example.roboapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;

public class TaskThread extends AsyncTask<String, Void, String>
{
   private static final String TAG = "TaskThread";

    private Context context;

    public TaskThread(Context context) {
        this.context = context;
    }

    @Override
    protected String doInBackground(String... params)
    {
        String url = params[0];

        // Create an HTTP client
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");

            // Execute the request
            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                // Get the response body
                InputStream inputStream = connection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                StringBuilder responseBody = new StringBuilder();
                int character;
                while ((character = inputStreamReader.read()) != -1) {
                    responseBody.append((char) character);
                }
                return responseBody.toString();
            }
            else
            {
                Log.e(TAG, "HTTP request failed with status code " + responseCode);
            }
        }
        catch(IOException e)
        {
            Log.e(TAG, "HTTP request failed with exception " + e.getMessage());
        }
        finally
        {
            if (connection != null)
            {
                connection.disconnect();
            }
        }

        return null;
    }

    @Override
    protected void onPostExecute(String result) 
    {
        LocalDateTime now = LocalDateTime.now();
        String res;
        if ( result == null)
        {
            res = "connection failed. Check connection and service status";
        }
        else
        {
            res = result + "-" + now;
        }
        MainActivity.resultsTextView.setText(res);
    }
}
