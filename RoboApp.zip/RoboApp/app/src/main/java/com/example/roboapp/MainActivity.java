package com.example.roboapp;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    static TextView resultsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultsTextView = (TextView) findViewById(R.id.status);


    }



    public void onPing(View view) {
        resultsTextView.setText("-");
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/ping");
        //Toast.makeText(this,"Ping test..",2).show();
    }

    public void onForward(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movef");
        Toast.makeText(this,"Forward", 2 ).show();
    }

    public void onBack(View view)
    {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/moveb");
        //Toast.makeText(this,"Back", 2 ).show();
    }

    public void onLeft(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movel");
    }

    public void onRight(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/mover");
    }


    public void onRFDL(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movefdl");
    }

    public void onRFDR(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movefdr");
    }

    public void onRBDL(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movebdl");
    }

    public void onRBDR(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movebdr");
    }

    public void onRRL(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/moverrl");
    }

    public void onRRR(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/moverrr");
    }

    public void onRCL(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movercl");
    }

    public void onRCR(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/movercr");
    }

    public void onRoboStop(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/vstop");
    }

    public void onEmergencyStop(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/stop");
    }

    public void onExtStop(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/estop");
    }

    public void OnExtIn(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/emoveb");
    }

    public void onExtOut(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/emovef");
    }

    public void onBrushStart(View view) {

        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/cstart");
    }

    public void onBrushStop(View view) {

        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/cstop");
    }

    public void onLowSpeed(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/lowspeed");
    }

    public void onMedSpeed(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/medspeed");
    }

    public void onHighSpeed(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/highspeed");
    }

    public void onMaxSpeed(View view) {
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/robo/maxspeed");
    }

    public void onShutdown(View view) {

        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/shutdown");
    }

    public void onRestart(View view) {
        resultsTextView.setText("Restarting ...");
        TaskThread task = new TaskThread(this);
        task.execute("http://vrobo:5000/reboot");
    }


}